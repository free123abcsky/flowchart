{
	"result" : true,
	"list" : [
		{
			"ID" : "jsPlumb_0",
			"taskID" : "jsPlumb_2_ttt",
			"state" : 1,
			"userNum" : 6000
		},
		{
			"ID" : "jsPlumb_1",
			"taskID" : "jsPlumb_3_ttt",
			"state" : 1,
			"userNum" : 90000
		}
	],
	"state" : "end",
	"error" : null
}