{
	"result" : true,
	"error" : "节点任务执行中，不可删除！"
}