{
	"result" : true,
	"icon" : {
		"ID" : "jsPlumb_959595",
		"taskID" : "123123",
		"type" : "start",
		"text" : "开始任务",
		"targetId" : "jsPlumb_1",
		"left": 50,
		"top": 50
	},
	"error" : null
}