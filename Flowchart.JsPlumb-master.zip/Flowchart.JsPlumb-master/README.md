# Flowchart.JsPlumb
Flowchart Editor using JsPlumb

Download project

Open jquery.html

Use Menu shapes to add them to working panel.

Use save button to save flowchart as json

you can also past json to text erea and use load button to redraw flowchart.

You can use, fork, change or redistribute as you like.

Author: Tamer Awad
